const numMonth_to_letter = (month) => {
  switch (month) {
    case 1:
      return "January";

    case 2:
      return "February";

    case 3:
      return "March";

    case 4:
      return "April";

    case 5:
      return "may";

    case 6:
      return "June";

    case 7:
      return "July";

    case 8:
      return "August";

    case 9:
      return "September";

    case 10:
      return "October";

    case 11:
      return "November";

    case 12:
      return "December";
    default:
      break;
  }
};
module.exports = {
  parse_date: (date,str) => {
    const day = date.getDate();
    const year = date.getFullYear();
    let month = date.getMonth();
    const hours = date.getHours();
    const mins = date.getMinutes();
    const str_month = numMonth_to_letter(month)
    return { day, year, str_month,month, date, hours, mins };
  },
  calculate_log_time: (logout_date, login_date) => {
    const total_hours = logout_date.hours - login_date.hours;
    const total_mins = Math.floor(logout_date.mins - login_date.mins);
    if (total_hours || total_mins > 10) return { ausence: true };
    return { total_hours, total_mins };
  },
};
