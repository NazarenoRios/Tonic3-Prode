const set_dir = require('.')
const { parse_date } = require('./init_date')
const { save_data } = require('./save_data')
const register_dir=set_dir('register_summary',{'created_acc':{},'deleted_acc':{}})
const {data,dir}=register_dir


const save_date=(date,action)=>{
    const {str_month,month,year}=date
    if(!data[action])data[action]={[year]:{[month]:{x:str_month,y:1}}}
    if(!data[action][year])data[action][year]={[month]:{x:str_month,y:1}}
    if(!data[action][year][month])data[action][year][month]={x:str_month,y:1}
    return save_data(dir,data)
}

module.exports={
    inc_registed_acc:()=>{
        const {year,month,str_month}=parse_date(new Date,true)
        if(!data['created_acc']) return save_date({year,str_month,month},'created_acc')
        if(!data['created_acc'][year])return save_date({year,str_month,month},'created_acc')
        if(!data['created_acc'][year][month])return save_date({year,str_month,month},'created_acc')
        data['created_acc'][year][month].y+=1
        save_data(dir,data)
    },
    inc_deleted_acc:()=>{
        const {year,month}=parse_date(new Date,true)
        if(!data['deleted_acc']) return save_date({year,str_month,month},'deleted_acc')
        data['deleted_acc'][year][month].y+=1
        save_data(dir,data)
        }
}